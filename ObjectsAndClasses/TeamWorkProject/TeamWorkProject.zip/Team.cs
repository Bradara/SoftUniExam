﻿namespace TeamWorkProject
{
    using System;
    using System.Collections.Generic;

    public class Team
    {
        public string Name { get; set; }
        public List<string> Users { get; set; }
        public string Creator { get; set; }
        
        public Team(string name, string user)
        {
            Name = name;
            Users = new List<string>();           
            Creator = user;
            Console.WriteLine($"Team {name} has been created by {user}!");        
        }
    }
}
